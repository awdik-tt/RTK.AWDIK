package com.example.dungeon;

import com.example.dungeon.core.Game;

public class Main {
    public static void main(String[] args) {
        new Game().run();
    }
}
